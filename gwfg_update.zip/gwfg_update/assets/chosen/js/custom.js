jQuery(document).ready(function($) {
	// body...
	$("select").chosen(
		{
			// max_selected_options: 5,
			// no_results_text: "Oops, nothing found!",
			// allow_single_deselect: true,
			// width: "20%",
		}
		);
});